package com.ayman.screen;

import com.ayman.game.MyGame;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.utils.ScreenUtils;

/**
 * Initialises the title screen, the first one seen by the player when the executable is started.
 */
public class TitleScreen extends ScreenAdapter{

    MyGame game;

    public  TitleScreen(MyGame game_instance) {
        this.game = game_instance;
    }

    @Override
    public void show(){
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean keyDown(int keyCode) {
                if (keyCode == Input.Keys.SPACE) {
                    game.setScreen(new GameScreen(game));
                }
                return true;
            }
        });
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0.6f, 1);
        //camera.position.set(bucket.x, bucket.y, 0);
        //game.camera.update();
        //game.batch.setProjectionMatrix(game.camera.combined);
        game.batch.begin();
        //game.font.draw(game.batch, "Title Screen!", Gdx.graphics.getWidth() * .25f, Gdx.graphics.getHeight() * .75f);
        //game.font.draw(game.batch, "Collect treasure to win!.", Gdx.graphics.getWidth() * .25f, Gdx.graphics.getHeight() * .5f);
        game.font.draw(game.batch, "Welcome to YORK PIRATES! \nDefeat all colleges to win! \nPress space to play.", game.player.x, game.player.y);
        game.batch.end();
    }

    @Override
    public void hide(){
        Gdx.input.setInputProcessor(null);
    }

}
