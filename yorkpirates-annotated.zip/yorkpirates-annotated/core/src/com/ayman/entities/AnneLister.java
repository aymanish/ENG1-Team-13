package com.ayman.entities;
/**
 * Extends the college class with information specific to the Anne lister College
 * 
 * x: x coordinate of the college building
 * y: y coordinate of the college building
 * HP: Health for the college building, effectively the amount of times it needs to be hit to be captured.
 * POINTS: Points gained from the capture of the college
 * png_npc: Sets the sprite used by affiliated NPC boats
 * collegeSprite: Sets the sprite used by the college itself
 * boundRect: The collision box for the college building
 * AOE: collision box used to denote area where the college will open fire on an enemy boat
 * 
 */
public class AnneLister extends College {
    public AnneLister() {
        x = 900; //800/2
        y = 900; //150
        HP = 5;
        POINTS = 500;
        //set college sprites for the building and boats.
        png_npc = "ship_AL";
        collegeSprite = textureAtlas.createSprite("anneLister_island");
        collegeSprite.setPosition(x, y);
        //set bounding rectangle based on college sprite
        boundRect = collegeSprite.getBoundingRectangle();
        boundRect.x = x;
        boundRect.y = y;
        //set AOE
        AOE.x = x+(width/2);
        AOE.y = y+(height/2);
    }
}
