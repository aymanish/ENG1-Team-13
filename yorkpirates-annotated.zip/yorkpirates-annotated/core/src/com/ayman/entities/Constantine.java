package com.ayman.entities;
/**
 * Extends the college class with information specific to the Constantine College
 * 
 * x: x coordinate of the college building
 * y: y coordinate of the college building
 * HP: Health for the college building
 * POINTS: Points gained from the capture of the college
 * png_npc: Sets the sprite used by affiliated NPC boats
 * collegeSprite: Sets the sprite used by the college itself
 * boundRect: The collision box for the college building
 * AOE: collision box used to denote area where the college will open fire on an enemy boat
 * 
 */
public class Constantine extends College {
    public Constantine() {
        x = 2000;
        y = 900;
        HP = 5;
        POINTS = 500;
        //set college sprites for the building and boats.
        png_npc = "ship_CT";
        collegeSprite = textureAtlas.createSprite("constantine_island");
        collegeSprite.setPosition(x, y);
        //set bounding rectangle based on college sprite
        boundRect = collegeSprite.getBoundingRectangle();
        boundRect.x = x;
        boundRect.y = y;
        //set AOE
        AOE.x = x+(width/2);
        AOE.y = y+(height/2);
    }
}
