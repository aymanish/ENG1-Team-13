package com.ayman.entities;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;

/**
 * Extends LibGDX's sprite class with information needed by every item on the screen
 * 
 * x,y,dx,dy,radians: used for various position renderings of the object
 * width: Width of the sprite in pixels
 * height: Height of the sprite in pixels
 * max:
 */

public class GameObject extends Sprite {

    public TextureAtlas textureAtlas = new TextureAtlas("sprites.txt");

    public float x;
    public float y;

    //vectors
    public float dx;
    public float dy;

    //angle
    public float radians;

    public int width;
    public int height;

    public boolean max;
}
