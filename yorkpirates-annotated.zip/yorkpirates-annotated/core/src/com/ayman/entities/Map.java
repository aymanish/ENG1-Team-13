package com.ayman.entities;

import com.ayman.game.MyGame;
import com.badlogic.gdx.graphics.g2d.Sprite;
/**
 * Loads the image used as the playspace for the game
 * 
 * Map: sets the image to be used as texture for the palyable area
 */
public class Map extends GameObject {
    public Sprite map;

    public Map() {
        map = textureAtlas.createSprite("boundary");
    }
}
