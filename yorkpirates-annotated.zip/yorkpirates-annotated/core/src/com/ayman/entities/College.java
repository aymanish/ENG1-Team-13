package com.ayman.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;

import java.util.ArrayList;

/**
 * Creates a basis for college objects to be made
 * 
 * HP: Health for the college building
 * POINTS: Points gained from the capture of the college
 * png_npc: Sets the sprite used by affiliated NPC boats
 * collegeSprite: Sets the sprite used by the college itself
 * boundRect: The collision box for the college building
 * AOE: collision box used to denote area where the college will open fire on an enemy boat
 * boundRect: The area used to detect impacts from projectiles, boats etc
 * bullets: Arraylist that holds all currently active projectiles belonging to the college
 * NPCs: ArrayList that holds all accociated Ship NPC objects
 * isAttacked: flag to denote whether a college has been attacked at some point by the player
 * isAOE: flag to denote whether the players boat is currently in a colleges targeting vicinity
 * MAX_COLLEGE_BULLETS: The amount of bullets fired in a single burst by the college
 * isCaptured: flag to denote whether a college has been captured (HP at 0)
 * npcCount: amount of associated NPC boats
 * 
 */

public class College extends GameObject{

    public Circle AOE;
    //public float bulletradians, bulletX, bulletY; //= 3.1415f/2
    public int HP, POINTS;
    public Sprite collegeSprite;
    public Rectangle boundRect;
    public ArrayList<Bullet> bullets;
    public ArrayList<npcShip> NPCs;
    public String png_npc;

    //aymans addition:
    public boolean isAttacked;
    public boolean isAOE;
    private final int MAX_COLLEGE_BULLETS = 1;
    public boolean isCaptured;

    public int npcCount = 3;
    //call generateNPC() function:


    public College() {

        this.bullets = new ArrayList<Bullet>();
        this.NPCs = new ArrayList<npcShip>();

        width = 174;
        height = 125;

        AOE = new Circle(x,y,250);

        isAttacked = false;
        isCaptured = false;
        isAOE = false;

    }

    //college firing system, we will return a sprite bullet when called
    public void shoot(float radians) {
        if (!isCaptured) {
            if (bullets.size() == MAX_COLLEGE_BULLETS) {return;}
            bullets.add(new Bullet(x + width/2f, y + height/2f, radians));
        }
    }

        //if (!isCaptured() && playerInRange()) {
            //return bullet with correct direction etc
            //need to implement firing rate somehow possibly in game screen section or
            //as a condition in this if statement difference between time called
      //  }
    //}
    //checks if player is in range to be fired at
    //public boolean playerInRange() {
       // if (//distance check/overlap of hit box etc
       // ) {
       //     return true;
      //  }
       // else {
         //   return false;
       // }
  //  }
    //what happens to a college when said college is hit by a bullet from player
    public void collegeHit() {
        if (!isCaptured) {
            HP--;
            System.out.println("COLLEGE HIT");
            isAttacked = false;
        }

        //players point gains in fireSuccess() method in PlayerShip class
    }


    /*
    //checks if college has been captured
    public boolean isCaptured() {
        if (HP == 0) {
            return true;
        }
        else {
            return false;
        }
    }
     */


}
