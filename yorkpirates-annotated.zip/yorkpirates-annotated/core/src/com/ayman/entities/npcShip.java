package com.ayman.entities;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Rectangle;
/**
 * Used to create non-player ships. Currently for decoration but with facilities for functionality in future
 * 
 * @param college_png String containing the file name of the desired ship sprite
 * 
 * npcSprite: The image used as the ship sprite
 * rectNPC: The bounding rectangle for the ship
 * MAX_BULLETS: The amount of bullets fired in a burst from the ship
 * sprite: creates a sprite from the filename provided to the method
 * dx: Accelerator value
 * dy: Accelerator value
 * width: Width of the sprite in pixels
 * height: Height of the sprite in pixels
 * maxSpeed: Fastest the object can move in pixels per frame
 * acceleration: speed of the movement when moving in a given direction
 * deceleration: speed of the movement when not moving in a given direction and slowing down
 * 
 */

public class npcShip extends Ship{

    public Sprite npcSprite;
    public Rectangle rectNPC;
    private final int MAX_BULLETS = 0;

    public npcShip(String college_png) {

        sprite = textureAtlas.createSprite(college_png);

        npcSprite = this.sprite;
        rectNPC = npcSprite.getBoundingRectangle();

        //need to manually set x,y
        dx = 0;
        dy = 0;
        width = 64;
        height = 64;

        //change if necessary for collisions against player ship
        maxSpeed = 0;
        acceleration = 0;
        deceleration = 0;

        //manually set radians
        radians = 0;
        rotationSpeed = 0;
    }

    public void update(float dt) {

        //insert any positional updates
        //can use the college bullet aim to update radians

        boundaries();
    }

}
